(defproject statim "0.1.0"
  :dependencies [[org.clojure/clojure "1.6.0"]
                 [incanter "1.5.5"]])
                 ; [incanter/incanter-zoo "1.5.5"]])
                 ; [org.clojure/data.csv "0.1.2"]])
                 ; [org.apache.directory.studio/org.apache.commons.collections "3.2.1"]
                 ; [clj-time "0.9.0-beta1"]
